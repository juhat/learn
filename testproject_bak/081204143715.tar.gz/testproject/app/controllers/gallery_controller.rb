class GalleryController < ApplicationController
end
