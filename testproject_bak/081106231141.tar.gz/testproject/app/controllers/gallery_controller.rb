class GalleryController < ApplicationController
  def index
   render :text=>'Hello my dear visitor!'
  end
end
