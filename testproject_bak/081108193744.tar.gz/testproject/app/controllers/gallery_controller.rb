class GalleryController < ApplicationController
  def index
    render :text=>'Hello my dear visitor!'
  end

  def about
    render :template=>'gallery/about_me.html.erb'
  end

end
