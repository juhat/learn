require File.dirname(__FILE__) + '/spec_helper'

  describe "The art gallery project" do
    it "should have a gallery controller file" do
      controller_exist?('gallery').should eql(true)
    end
    it "should have a painting scaffold - each painting needs title, author and image_path attributes" do
      scaffold_exist?('painting').should eql(true)
    end
  end
  
  describe GalleryController, :type => :controller do
    it "should have an index action" do
      controller.respond_to?(:index).should be_true
    end
  end
