require File.dirname(__FILE__) + '/spec_helper'

  describe "The art gallery project" do
    it "should have a gallery controller file" do
      controller_exist?('gallery').should eql(true)
    end
    it "should have a painting scaffold - each painting needs title, author and image_path attributes" do
      scaffold_exist?('painting').should eql(true)
    end
  end
  
  describe "" do
    it "should have a gallery controller file" do
      controller_exist?('gallery').should eql(true)
    end
    it "should have a painting scaffold" do
      scaffold_exist?('painting').should eql(true)
    end
  end
  
  describe "Art Galley" do
    it "Create a webshop! Use scaffold to generate the shop admin interface!"

    it "should be accessible at /shop" do
      true.should eql(true)
    end
    it "should be true" do
      true.should eql(false)
    end
  end