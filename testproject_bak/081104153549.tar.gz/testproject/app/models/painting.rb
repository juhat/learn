class Painting < ActiveRecord::Base
end
