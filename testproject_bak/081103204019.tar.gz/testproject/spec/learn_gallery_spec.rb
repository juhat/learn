require File.dirname(__FILE__) + '/spec_helper'

if (controller_exist?('gallery') AND scaffold_exist?('painting'))
    
  describe "Art Galley" do
    it "Create a webshop! Use scaffold to generate the shop admin interface!"

    it "should be accessible at /shop" do
      true.should eql(true)
    end
    it "should be true" do
      true.should eql(false)
    end
  end

else

  describe "Art Gallery" do
    it "should have a gallery controller file" do
      controller_exist?('gallery').should eql(true)
    end
    it "should have a painting scaffold" do
      scaffold_exist?('painting').should eql(true)
    end
  end

end  
