# This controller will be copied to the new testproject.
# It will provide the feedback to the LEARN environment.
# This separation help us to separate code and programs by rights.

require 'spec'
class LearnCourseController < ApplicationController  
  def autotest
    # out, err = StringIO.new('',"w+"), StringIO.new('',"w+")
    # ::Spec::Runner::CommandLine.run(::Spec::Runner::OptionParser.parse(["#{RAILS_ROOT}/spec/learn_gallery_spec.rb",'-f html','-t 10','-c'], err, out))
    render :text => out.string
  end
  
  # NEED WORK
  def console
    result = nil
    begin
      result = eval(params[:command])
    rescue Exception => ex
      result = ex.to_s
    end
    render :text=> result
  end
  
  def terminal
    t = Thread.new { `cd testproject && #{params[:command]}` }
    tval = t.value
    t.exit! 
    render :text=>tval
  end
end