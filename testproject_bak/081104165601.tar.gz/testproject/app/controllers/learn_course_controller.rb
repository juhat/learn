require 'hpricot'

class LearnCourseController < ApplicationController
  
  def spec_server_start
    `rake spec:server:start`
  end
  
  def spec_server_stop
    `rake spec:server:stop`
  end
  
  def autotest
    doc =  Hpricot( `script/spec -X -o spec/spec.opts spec/learn_gallery_spec.rb` )
    (doc/".not_implemented_spec_name").each{|e| e.inner_html = e.inner_html[0,e.inner_html.index('(')] }
    header = File.readlines('testproject/spec/learn_story.html').map {|l| l.rstrip}
    render :text => header + (doc/".results")
  end
  
  # NEED WORK
  def console
    result = nil
    begin
      result = eval(params[:command])
    rescue Exception => ex
      result = ex.to_s
    end
    render :text=> result
  end
  
  def terminal
    t = Thread.new { `cd testproject && #{params[:command]}` }
    tval = t.value
    t.exit! 
    render :text=>tval
  end
end